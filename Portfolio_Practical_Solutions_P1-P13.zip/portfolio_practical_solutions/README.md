# Portfolio Practical Solutions (P1–P13)

Beginner-friendly starter project for VS Code.

## Open and run
1. Download and unzip this folder.
2. Open the folder in VS Code (`File → Open Folder`).
3. Open `index.html` in a browser, or use the Live Server extension.
4. Other demos: `bio.html`, `flex-demo.html`, `newspaper.html`, and `projects-grid.html`.

## P1 — Project folder and terminal navigation
Create/open this folder and use:
```bash
pwd
ls
mkdir assets
mkdir css
mkdir js
touch index.html
touch css/style.css
```
On Windows PowerShell, use `New-Item index.html -ItemType File` if `touch` is unavailable.

## P2 — Portfolio repository and first commit
```bash
git init
git add .
git commit -m "Initial portfolio project"
```
Create an empty repository on GitHub, then connect it (replace the URL):
```bash
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

## P3 — Feature branch workflow
```bash
git switch -c feature/about-section
# Make and save your changes
git status
git add .
git commit -m "Add about section"
git push -u origin feature/about-section
```
On GitHub, open a Pull Request from `feature/about-section` into `main`. After review/merge:
```bash
git switch main
git pull origin main
```

## P4 — README and version tags
Edit this README with your name, project description, features, and setup instructions.
```bash
git add README.md
git commit -m "Add project README"
git tag -a v1.0 -m "First portfolio release"
git push origin main
git push origin v1.0
```

## Practical mapping
- P5: `bio.html` + `css/bio.css` — semantic bio page.
- P6: `index.html` + `css/style.css` — semantic portfolio.
- P7: CSS custom properties and typography in `css/style.css`.
- P8: sticky navbar and positioned project-card label in `css/style.css`.
- P9: responsive Flexbox navigation and project cards in `css/style.css`.
- P10: advanced Flexbox header/footer in `flex-demo.html` + `css/flex-demo.css`.
- P11: three-column newspaper layout in `newspaper.html` + `css/newspaper.css`.
- P12: responsive CSS Grid projects in `projects-grid.html` + `css/projects-grid.css`.
- P13: comparison and selection guide at the end of this README.

## P13 — When to use Flexbox vs Grid
- Use **Flexbox** for one-dimensional layouts: a row OR a column, such as navigation links, buttons, and header alignment.
- Use **Grid** for two-dimensional layouts: rows AND columns, such as a newspaper page or project gallery.
- They can be combined. For example, use Grid for the overall page and Flexbox inside each card.
